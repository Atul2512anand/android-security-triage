ADB OVER TCP - ONE-TIME USB HELPER
==================================

Use this when the phone cannot run Wireless debugging and Tailscale
at the same time.

WHAT IT DOES
------------
It connects to the phone over USB once and switches Android's ADB
daemon to TCP port 5555. After that you can unplug USB. The phone can
stay on mobile data, Tailscale stays connected, and the operator
connects over Tailscale.

REQUIREMENTS
------------
- Windows 10 or 11 computer.
- A USB cable that carries data (not charge-only).
- The phone unlocked.
- USB debugging enabled.

STEP BY STEP
------------
1. Unzip this whole folder somewhere, for example the Desktop.
2. On the phone:
   Settings > About phone > OS version (tap 7 times).
   Settings > Developer options > USB debugging: ON.
   Xiaomi/Redmi: also turn on "USB debugging (Security settings)"
   if that option exists.
3. Connect the phone to the computer with USB.
4. Unlock the phone. If a USB mode notification appears, choose
   "File transfer" (MTP).
5. Double-click ENABLE-ADB-TCPIP.bat.
6. When the phone asks "Allow USB debugging?", tap Allow.
   Tick "Always allow from this computer" if shown.
7. Wait for "DONE". Unplug USB.
8. Keep mobile data ON and Tailscale Connected.
9. Tell the operator: "TCP mode is enabled on port 5555".

IF THE PHONE IS NOT FOUND
-------------------------
- Use a different USB cable (data cable).
- Try another USB port.
- On Windows, install the Xiaomi USB driver if the phone is not
  recognized. Windows Update usually installs it automatically.
- On the phone: Developer options > Revoke USB debugging
  authorizations, then reconnect and tap Allow again.

SECURITY
--------
Port 5555 is open on the phone while TCP mode is on. It is only
reachable over the Tailscale private network, not the public internet.
When the scan is finished:
- reconnect USB and run DISABLE-ADB-TCPIP.bat, or
- restart the phone.
This closes port 5555.

TROUBLESHOOTING
---------------
If ENABLE-ADB-TCPIP.bat says "more than one device", close any
emulator or other phone connected to the computer and run it again.

If Windows does not see the phone at all, open Device Manager and
look for an unknown Android device. Install the Xiaomi USB driver,
or use another computer.
