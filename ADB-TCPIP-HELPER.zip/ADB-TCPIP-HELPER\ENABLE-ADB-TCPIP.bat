@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Enable ADB over TCP (port 5555)
color 0B

echo ============================================================
echo   ENABLE ADB OVER TCP  -  one-time USB step
echo ============================================================
echo.
echo This lets the operator connect to this phone over Tailscale
echo WITHOUT Wireless debugging, so the phone can stay on mobile
echo data and Tailscale stays connected.
echo.
echo WHAT TO DO:
echo   1. Connect the phone to this computer with a USB cable.
echo   2. Unlock the phone.
echo   3. Enable Developer options and USB debugging:
echo        Settings ^> About phone ^> OS version (tap 7 times)
echo        Settings ^> Developer options ^> USB debugging: ON
echo      Xiaomi/Redmi: also turn ON "USB debugging (Security settings)"
echo      if that option exists.
echo   4. When the phone asks "Allow USB debugging?", tap Allow.
echo      Tick "Always allow from this computer" if shown.
echo   5. If the phone shows a USB mode notification, choose
echo      "File transfer" (MTP), not "Charging only".
echo.
echo Press any key when the phone is connected and unlocked.
pause >nul

set "ADB=%~dp0platform-tools\adb.exe"
if not exist "%ADB%" (
  echo.
  echo ERROR: platform-tools\adb.exe is missing.
  echo Unzip the WHOLE folder, not just this .bat file.
  echo.
  pause
  exit /b 1
)

:findphone
echo.
echo Looking for the phone...
"%ADB%" devices
"%ADB%" devices | findstr /r /c:"device$" >nul
if not errorlevel 1 goto found

echo.
echo No authorized phone found yet.
echo   - Use a DATA cable, not a charge-only cable.
echo   - Unlock the phone and tap Allow on "Allow USB debugging?".
echo   - If the phone says "unauthorized", tap Allow.
echo   - Try another USB port.
echo   - Windows may need the Xiaomi USB driver.
echo.
echo Press any key to try again, or close this window to stop.
pause >nul
goto findphone

:found
echo.
echo Phone found.
echo Switching ADB to TCP mode on port 5555...
"%ADB%" -d tcpip 5555
if errorlevel 1 (
  echo.
  echo Failed. Check the USB cable, unlock the phone, and make sure
  echo USB debugging is ON. Then run this file again.
  echo.
  pause
  exit /b 1
)

echo.
echo ============================================================
echo   DONE
echo ============================================================
echo.
echo   1. You can unplug the USB cable now.
echo   2. Keep MOBILE DATA on.
echo   3. Open Tailscale and make sure it says Connected.
echo   4. Tell the operator: "TCP mode is enabled on port 5555".
echo.
echo To close port 5555 later:
echo   - reconnect USB and run DISABLE-ADB-TCPIP.bat, or
echo   - restart the phone.
echo.
pause
