@echo off
setlocal
cd /d "%~dp0"
title Disable ADB over TCP
color 0E

echo ============================================================
echo   DISABLE ADB OVER TCP
echo ============================================================
echo.
echo Connect the phone to this computer with the USB cable.
echo Unlock the phone.
echo.
pause

set "ADB=%~dp0platform-tools\adb.exe"
if not exist "%ADB%" (
  echo.
  echo ERROR: platform-tools\adb.exe is missing.
  echo Unzip the WHOLE folder.
  echo.
  pause
  exit /b 1
)

"%ADB%" usb
echo.
echo If it said "restarting in USB mode", TCP mode is now off.
echo You can also simply restart the phone to close port 5555.
echo.
pause
